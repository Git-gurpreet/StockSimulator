﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;


namespace Observerlib
{
    public class APIcaller
    {
        /// <summary>
        /// This method is to call the Web API and get the Stock price for each stock.
        /// </summary>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <returns>Stock Price , Ticker Time, errormessage if any.</returns>
        public Response callapi(int min, int max)
        {
            Response res = new Response();

            try
            {
                string baseadress = "http://localhost:53388/"; // ConfigurationManager.AppSettings["CardReplacementAPI"] as string;
                var builder = new UriBuilder(baseadress + "/api/StockData/getStockPrice");
                                string port = "53388";
                builder.Port = Convert.ToInt32(port);
                var query = HttpUtility.ParseQueryString(builder.Query);
                query["min"] = Convert.ToString(min);
                query["max"] = Convert.ToString(max);

                builder.Query = query.ToString();
                string url = builder.ToString();
                dynamic response;
                using (HttpClient httpClient = new HttpClient())
                {
                    httpClient.DefaultRequestHeaders.Clear();
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    response = httpClient.GetAsync(url).Result;
                }
                HttpResponseMessage responsemsg = response;


                if (responsemsg.IsSuccessStatusCode)
                {
                    string stringResponse = response.Content.ReadAsStringAsync().Result;
                    Response actionResponse = JsonConvert.DeserializeObject<Response>(stringResponse);

                    res.Success = actionResponse.Success;
                    res.ErrorMessage = actionResponse.ErrorMessage;
                    res.StockPrice = actionResponse.StockPrice;
                    res.TickerTime = actionResponse.TickerTime;
                }
                else
                {
                    res.Success = false;

                    res.ErrorMessage = responsemsg.ReasonPhrase;
                }

            }
            catch (Exception ex)
            {
                res.Success = false;
                res.ErrorMessage = ex.Message;
                
            }
            return res;

        }




    }

    public class Response
    {

        public int? StockPrice { get; set; }


        public bool Success { get; set; }

        public DateTime TickerTime { get; set; }


        public string ErrorMessage { get; set; }


    }
}

