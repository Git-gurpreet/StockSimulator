﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observerlib
{
    public class Observer : IObserver
    {
        public string ObserverName { get; private set; }

        public int min { get; private set; }

        public int max { get; private set; }

        public int prevPrice { get; private set; }


        public Observer(string name , int min, int max,int prevPrice )
        {        
            this.ObserverName = name;
            this.min = min;
            this.max = max;
            this.prevPrice = prevPrice;
                      
        }

    
        /// <summary>
        /// This function calls the API to get the results for each subsciber and displays it to console.
        /// </summary>
        public void publishStockInfo()
        {
            try
            {

                APIcaller obj = new APIcaller();
                var response = obj.callapi(this.min, this.max);

                if (response.Success)
                {
                    if (response.StockPrice > this.prevPrice)
                        Console.ForegroundColor = ConsoleColor.Green;
                    else Console.ForegroundColor = ConsoleColor.Red;

                    this.prevPrice = Convert.ToInt32(response.StockPrice);
                    Console.WriteLine("Stock info for Subscriber " + this.ObserverName + " Price: " + response.StockPrice + " Time: " + response.TickerTime);
                }
                else
                    Console.WriteLine("Error returned from API , Please see this message: " + response.ErrorMessage);

            }
            catch(Exception ex)
            {
                Console.WriteLine("Error getting data from API , Please check if API is working.  "+ ex.Message);
            }
        }
    }

   
}
