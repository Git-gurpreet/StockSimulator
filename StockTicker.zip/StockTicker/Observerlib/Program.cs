﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Observerlib
{
    public class Subscription
    {
        static void Main(string[] args)
        {
            Subject subject = new Subject();   
            
            Observer observer1 = new Observer("Stock 1", 240, 270,0);    //Defining properties of Observer 1 
            Observer observer2 = new Observer("Stock 2", 180, 210,0);      // Defining properties of Observer 2
            Console.WriteLine("Enter 1 for subscribing Stock 1.");
            Console.WriteLine("Enter 2 for subscribing Stock 2.");
            Console.WriteLine("Enter 3 for subscribing both(stock1 and stock2)");
            Console.WriteLine("Enter 4 for subscribing both stocks and to see one stock getting Unsubscribed after few iterations.");
            int option =  Convert.ToInt32( Console.ReadLine());
            if(option ==1)
            {

                subject.Subscribe(observer1);
                NotifyResults(subject);
            }
            else if (option== 2)
            {
                subject.Subscribe(observer2);
                NotifyResults(subject);
            }
            else if (option==3)
            {
                subject.Subscribe(observer1);
                subject.Subscribe(observer2);
                NotifyResults(subject);

            }
            else if (option== 4)
            {
                subject.Subscribe(observer1);
                subject.Subscribe(observer2);
                DemonstrateUnsubsctiption(subject);

            }
            else
            {
                Console.WriteLine("Selected incorrect option.");
            }

             


        }

        /// <summary>
        /// Notify all the Subscribers with new stock prices every second.
        /// </summary>
        /// <param name="subj"></param>
        public static void NotifyResults( Subject subj)
        {
            
            try
            {
             
                Task task = new Task(() =>
                {
                    while (true)
                    {
                        
                        subj.Notify();
                        
                        Thread.Sleep(1000);
                    }
                });
                task.Start();




                Console.ReadLine();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while Notifying the Subscribers: "+ex.Message);
            }
        }

        /// <summary>
        /// This function function will notify all the subscribers but will also unsubscribe first Subscriber after few iterations.
        /// It is just to demonstrate unsubscribing.
        /// </summary>
        /// <param name="subj"></param>
        public static void DemonstrateUnsubsctiption(Subject subj)
        {

            try
            {
                int i = 0;
                Task task = new Task(() =>
                {
                    while (true)
                    {
                        i++;
                        if (i == 4) subj.Unsubscribe(subj.observers.First());
                        subj.Notify();

                        Thread.Sleep(1000);
                    }
                });
                task.Start();




                Console.ReadLine();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while Notifying the Subscribers: " + ex.Message);
            }
        }

       }
}
