﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Observerlib
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.


    public class Subject : ISubject
    {
        private Observer _observer;
        public List<Observer> observers = new List<Observer>();

        /// <summary>
        ///Add the subscibers to the list , so that they can be notified. 
        /// </summary>
        /// <param name="observer"></param>
        public void Subscribe(Observer observer)
        {
            Console.WriteLine("Subscriber: " + observer.ObserverName + " is subscribed.");
            observers.Add(observer);
            this._observer = observer;
         }

        /// <summary>
        /// Removes subscibers so they won't get notified.
        /// </summary>
        /// <param name="observer"></param>
        public void Unsubscribe(Observer observer)
        {
            observers.Remove(observer);
            Console.WriteLine("Subscriber: " + observer.ObserverName + " is Unsubscribed.");

        }

        /// <summary>
        /// This function Notifies all the subscibers as per their definition.
        /// </summary>
        public void Notify()
        {
           
            foreach (var i in observers)
            {
                 i.publishStockInfo();
            }
           
         }
    }

}
