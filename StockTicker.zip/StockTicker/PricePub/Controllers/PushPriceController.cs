﻿using PricePub.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PricePub.Controllers
{


    [RoutePrefix("api/StockData")]
    public class PushPriceController : ApiController
    {
        /// <summary>
        /// Api/Publisher to return the Simulated stock prices based on given range.
        /// </summary>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("getStockPrice")]
        public IHttpActionResult getStock([FromUri] int min, [FromUri] int max)
        {
            
            Response response = new Response();
            try
            {
                response = Stockhelper.GeneratestockPrice(min,max);
                return Ok(response);
            }
            catch (Exception ex)
            {
                
                response.ErrorMessage = "Error encountered while getting the stock price" + ex.Message;
                response.Success = false;
                return Ok(response);
            }
        }



    }
}
