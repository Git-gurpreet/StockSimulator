﻿using System;


namespace PricePub.Models
{
    
    public class Response
    {       
            
            public int? StockPrice { get; set; }
        
            
            public bool Success { get; set; }

            public DateTime TickerTime { get; set; }

            
            public string ErrorMessage { get; set; }

            
           }

    /// <summary>
    /// This function is generating random stock numbers.
    /// </summary>
     public class Stockhelper
    {

        public static Response GeneratestockPrice(int min, int max)
        {
            Response res = new Response();


            try
            {
                Random rnd = new Random();
                               

                res.StockPrice= rnd.Next(min, max);
                res.Success = true;
                res.TickerTime = DateTime.Now;
                res.ErrorMessage = string.Empty;
                 

            }
            catch(Exception ex)
            {
                res.ErrorMessage = "Problem occurred while getting the stock price" + ex.Message;
                res.Success = false;
            }
            return res;

            

        }
    }
}